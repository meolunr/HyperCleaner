MODDIR=${0%/*}
SYSTEM_DIR_PREFIX_COUNT=$(($(printf $MODDIR | wc -c) + 7))

for i in $(find $MODDIR/system/my_* -type f -not -name .replace); do
	mount -o bind $i ${i:$SYSTEM_DIR_PREFIX_COUNT}
done
for i in $(find $MODDIR/system/my_* -type f -name .replace); do
	path=$(dirname $i)
	mount -o bind $path ${path:$SYSTEM_DIR_PREFIX_COUNT}
done

